/* 
 * File:   header.h
 * Author: rdm10
 *
 * Created on 19 October 2015, 12:45
 */

#ifndef HEADER_H
#define	HEADER_H

#ifdef	__cplusplus
extern "C" {
#endif

float inches2metres(float feet, float inches);


#ifdef	__cplusplus
}
#endif

#endif	/* HEADER_H */

