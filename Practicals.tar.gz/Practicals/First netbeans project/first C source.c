
#include <stdio.h>

/*this is a first C Program*/

main()
{
int a,b,c; /*define three integer variables*/

	a=4; b=5; /*give them values*/
	c=a / b; /*add them up*/
	
	/*Print out some answers*/
printf("This sum of %d and %d is %d\n", a, b, c);
}