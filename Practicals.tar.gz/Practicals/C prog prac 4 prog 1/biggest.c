int get_biggest (int a, int b){
    int c;
    if(a<b) {
        c = b;
    } else {
        c=a;
    }
    return c;
}
