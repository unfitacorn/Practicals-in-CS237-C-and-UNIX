int multiply(int a, int b) {
    int c;
    
    c= a*b;
    
    return c;
}